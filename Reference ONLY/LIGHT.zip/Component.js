import React from "react";



export const Component = () => {
  return (
<div id="webcrumbs"> 
        	<div className="bg-white min-h-screen">
	  {/* Header */}
	  <header className="py-6 px-8 md:px-16 lg:px-24 flex justify-between items-center border-b border-gray-100">
	    <div className="flex items-center gap-2">
	      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
	        <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
	        <path d="M2 17L12 22L22 17" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
	        <path d="M2 12L12 17L22 12" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
	      </svg>
	      <h1 className="font-bold text-2xl tracking-tighter">XENIA</h1>
	    </div>
	    <nav className="hidden md:flex items-center gap-8">
	      <a href="#features" className="text-sm font-medium hover:underline transition-all">Features</a>
	      <a href="#how-it-works" className="text-sm font-medium hover:underline transition-all">How it Works</a>
	      <a href="#pricing" className="text-sm font-medium hover:underline transition-all">Pricing</a>
	      <a href="#faq" className="text-sm font-medium hover:underline transition-all">FAQ</a>
	    </nav>
	    <div className="flex items-center gap-4">
	      <a href="/login" className="text-sm font-medium hover:underline transition-all">Log in</a>
	      <a href="/register" className="bg-black text-white px-4 py-2 text-sm font-medium rounded-md hover:bg-gray-800 transition-all">Sign up</a>
	    </div>
	  </header>
	
	  {/* Hero Section */}
	  <section className="py-24 px-8 md:px-16 lg:px-24 grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
	    <div className="space-y-8">
	      <div className="inline-flex items-center px-3 py-1 rounded-full bg-gray-100 text-xs font-medium">
	        AI-Powered Education
	      </div>
	      <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tighter leading-tight">
	        Your Personal 
	        <span className="text-primary-500 relative ml-2">
	          AI Study
	          <svg className="absolute -bottom-2 left-0 w-full" viewBox="0 0 180 8" fill="none" xmlns="http://www.w3.org/2000/svg">
	            <path d="M1 5.5C36.5 2 72 1 180 6.5" stroke="black" strokeWidth="2" strokeLinecap="round"/>
	          </svg>
	        </span> 
	        <br/>Planner
	      </h1>
	      <p className="text-lg text-gray-600 max-w-md">
	        Generate personalized study plans, get help from AI tutors, and track your progress with powerful analytics.
	      </p>
	      <div className="flex flex-col sm:flex-row gap-4">
	        <a href="/register" className="bg-black text-white px-6 py-3 font-medium rounded-md hover:bg-gray-800 transition-all text-center">
	          Get Started Free
	        </a>
	        <a href="#how-it-works" className="border border-gray-200 px-6 py-3 font-medium rounded-md hover:bg-gray-50 transition-all text-center">
	          See How It Works
	        </a>
	      </div>
	      <div className="flex items-center gap-4">
	        <div className="flex -space-x-2">
	          <img src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3MzkyNDZ8MHwxfHNlYXJjaHwxfHx1c2VyfGVufDB8fHx8MTc1NjU5ODQ4Mnww&ixlib=rb-4.1.0&q=80&w=1080" alt="User" className="w-8 h-8 rounded-full border-2 border-white" />
	          <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3MzkyNDZ8MHwxfHNlYXJjaHwyfHx1c2VyfGVufDB8fHx8MTc1NjU5ODQ4Mnww&ixlib=rb-4.1.0&q=80&w=1080" alt="User" className="w-8 h-8 rounded-full border-2 border-white" />
	          <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3MzkyNDZ8MHwxfHNlYXJjaHwzfHx1c2VyfGVufDB8fHx8MTc1NjU5ODQ4Mnww&ixlib=rb-4.1.0&q=80&w=1080" alt="User" className="w-8 h-8 rounded-full border-2 border-white" />
	        </div>
	        <p className="text-sm text-gray-600">Trusted by 10,000+ students worldwide</p>
	      </div>
	    </div>
	    <div className="relative">
	      <div className="absolute -top-20 -left-20 w-64 h-64 bg-primary-50 rounded-full opacity-50 blur-3xl"></div>
	      <div className="relative bg-white border border-gray-100 rounded-2xl shadow-lg p-6 transform transition-all hover:scale-[1.02]">
	        <div className="flex justify-between items-center mb-6">
	          <h3 className="text-lg font-bold">Today's Study Plan</h3>
	          <span className="text-sm font-medium bg-green-50 text-green-700 px-2 py-1 rounded-md">On Track</span>
	        </div>
	        <div className="space-y-4">
	          <div className="bg-gray-50 p-4 rounded-lg">
	            <div className="flex justify-between items-center mb-2">
	              <h4 className="font-medium">Organic Chemistry</h4>
	              <span className="text-xs text-gray-500">45 min</span>
	            </div>
	            <div className="w-full bg-gray-200 h-2 rounded-full">
	              <div className="bg-primary-500 h-2 rounded-full" style={{width: '60%'}}></div>
	            </div>
	          </div>
	          <div className="bg-gray-50 p-4 rounded-lg">
	            <div className="flex justify-between items-center mb-2">
	              <h4 className="font-medium">Calculus - Derivatives</h4>
	              <span className="text-xs text-gray-500">30 min</span>
	            </div>
	            <div className="w-full bg-gray-200 h-2 rounded-full">
	              <div className="bg-primary-500 h-2 rounded-full" style={{width: '30%'}}></div>
	            </div>
	          </div>
	          <div className="bg-gray-50 p-4 rounded-lg">
	            <div className="flex justify-between items-center mb-2">
	              <h4 className="font-medium">Physics - Kinematics</h4>
	              <span className="text-xs text-gray-500">60 min</span>
	            </div>
	            <div className="w-full bg-gray-200 h-2 rounded-full">
	              <div className="bg-primary-500 h-2 rounded-full" style={{width: '0%'}}></div>
	            </div>
	          </div>
	        </div>
	        <button className="w-full mt-6 border border-gray-200 px-4 py-3 rounded-md font-medium hover:bg-gray-50 transition-all">
	          View Full Plan
	        </button>
	      </div>
	    </div>
	  </section>
	
	  {/* Features Section */}
	  <section id="features" className="py-24 px-8 md:px-16 lg:px-24">
	    <div className="text-center mb-16">
	      <h2 className="text-4xl font-bold tracking-tighter mb-4">Key Features</h2>
	      <p className="text-gray-600 max-w-2xl mx-auto">
	        XENIA combines artificial intelligence with proven learning techniques to help you study smarter, not harder.
	      </p>
	    </div>
	
	    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
	      <div className="bg-white border border-gray-100 rounded-2xl p-6 hover:shadow-lg transition-all">
	        <div className="w-12 h-12 bg-primary-50 rounded-full flex items-center justify-center mb-4">
	          <span className="material-symbols-outlined">calendar_month</span>
	        </div>
	        <h3 className="text-xl font-bold mb-2">Personalized Study Planner</h3>
	        <p className="text-gray-600">
	          AI-generated study schedules based on your syllabus, assessment results, and learning patterns.
	        </p>
	      </div>
	
	      <div className="bg-white border border-gray-100 rounded-2xl p-6 hover:shadow-lg transition-all">
	        <div className="w-12 h-12 bg-primary-50 rounded-full flex items-center justify-center mb-4">
	          <span className="material-symbols-outlined">smart_toy</span>
	        </div>
	        <h3 className="text-xl font-bold mb-2">AI Tutor</h3>
	        <p className="text-gray-600">
	          Get instant help with difficult concepts, solve doubts with OCR support, and receive targeted recommendations.
	        </p>
	      </div>
	
	      <div className="bg-white border border-gray-100 rounded-2xl p-6 hover:shadow-lg transition-all">
	        <div className="w-12 h-12 bg-primary-50 rounded-full flex items-center justify-center mb-4">
	          <span className="material-symbols-outlined">quiz</span>
	        </div>
	        <h3 className="text-xl font-bold mb-2">Assessments</h3>
	        <p className="text-gray-600">
	          Upload your test results to identify knowledge gaps and automatically adjust your study plan.
	        </p>
	      </div>
	
	      <div className="bg-white border border-gray-100 rounded-2xl p-6 hover:shadow-lg transition-all">
	        <div className="w-12 h-12 bg-primary-50 rounded-full flex items-center justify-center mb-4">
	          <span className="material-symbols-outlined">analytics</span>
	        </div>
	        <h3 className="text-xl font-bold mb-2">Progress Analytics</h3>
	        <p className="text-gray-600">
	          Visualize your learning journey with intuitive charts, mastery heatmaps, and performance insights.
	        </p>
	      </div>
	
	      <div className="bg-white border border-gray-100 rounded-2xl p-6 hover:shadow-lg transition-all">
	        <div className="w-12 h-12 bg-primary-50 rounded-full flex items-center justify-center mb-4">
	          <span className="material-symbols-outlined">military_tech</span>
	        </div>
	        <h3 className="text-xl font-bold mb-2">Gamification</h3>
	        <p className="text-gray-600">
	          Stay motivated with XP, levels, achievements, and streaks that make studying more engaging.
	        </p>
	      </div>
	
	      <div className="bg-white border border-gray-100 rounded-2xl p-6 hover:shadow-lg transition-all">
	        <div className="w-12 h-12 bg-primary-50 rounded-full flex items-center justify-center mb-4">
	          <span className="material-symbols-outlined">groups</span>
	        </div>
	        <h3 className="text-xl font-bold mb-2">Teacher & Parent Support</h3>
	        <p className="text-gray-600">
	          Allow teachers to tag weak topics and share progress reports with parents for comprehensive support.
	        </p>
	      </div>
	    </div>
	  </section>
	
	  {/* Testimonials */}
	  <section className="py-24 px-8 md:px-16 lg:px-24 bg-gray-50">
	    <div className="text-center mb-16">
	      <h2 className="text-4xl font-bold tracking-tighter mb-4">What Students Say</h2>
	      <p className="text-gray-600 max-w-2xl mx-auto">
	        Hear from students who have transformed their study habits with XENIA.
	      </p>
	    </div>
	
	    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
	      <div className="bg-white p-8 rounded-2xl border border-gray-100 hover:shadow-lg transition-all">
	        <div className="flex items-center gap-2 mb-2">
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	        </div>
	        <p className="text-lg mb-6">"XENIA helped me organize my study time and focus on my weak areas. I improved my grades by 15% in just one semester!"</p>
	        <div className="flex items-center gap-4">
	          <img src="https://images.unsplash.com/photo-1614544048536-0d28caf77f41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3MzkyNDZ8MHwxfHNlYXJjaHwxfHxzYXJhaCUyMGoufGVufDB8fHx8MTc1NjY0MzE3Nnww&ixlib=rb-4.1.0&q=80&w=1080" alt="Sarah J." className="w-12 h-12 rounded-full" />
	          <div>
	            <h4 className="font-bold">Sarah J.</h4>
	            <p className="text-sm text-gray-600">Medical Student</p>
	          </div>
	        </div>
	      </div>
	
	      <div className="bg-white p-8 rounded-2xl border border-gray-100 hover:shadow-lg transition-all">
	        <div className="flex items-center gap-2 mb-2">
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	        </div>
	        <p className="text-lg mb-6">"The AI tutor is like having a personal teacher available 24/7. It explains difficult concepts in a way I can understand."</p>
	        <div className="flex items-center gap-4">
	          <img src="https://images.unsplash.com/photo-1620477403960-4188fdd7cee0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3MzkyNDZ8MHwxfHNlYXJjaHwxfHxtaWNoYWVsJTIwdC58ZW58MHx8fHwxNzU2NjQzMTc3fDA&ixlib=rb-4.1.0&q=80&w=1080" alt="Michael T." className="w-12 h-12 rounded-full" />
	          <div>
	            <h4 className="font-bold">Michael T.</h4>
	            <p className="text-sm text-gray-600">High School Student</p>
	          </div>
	        </div>
	      </div>
	
	      <div className="bg-white p-8 rounded-2xl border border-gray-100 hover:shadow-lg transition-all">
	        <div className="flex items-center gap-2 mb-2">
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	          <span className="text-yellow-400">★</span>
	        </div>
	        <p className="text-lg mb-6">"As a teacher, I can see which topics my students struggle with and provide targeted help. XENIA has transformed my classroom."</p>
	        <div className="flex items-center gap-4">
	          <img src="https://images.unsplash.com/photo-1741880295874-72b665807375?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3MzkyNDZ8MHwxfHNlYXJjaHwxfHxsaW5kYSUyMG0ufGVufDB8fHx8MTc1NjY0MzE3OHww&ixlib=rb-4.1.0&q=80&w=1080" alt="Linda M." className="w-12 h-12 rounded-full" />
	          <div>
	            <h4 className="font-bold">Linda M.</h4>
	            <p className="text-sm text-gray-600">Physics Teacher</p>
	          </div>
	        </div>
	      </div>
	    </div>
	  </section>
	
	  {/* How it Works */}
	  <section id="how-it-works" className="py-24 px-8 md:px-16 lg:px-24">
	    <div className="text-center mb-16">
	      <h2 className="text-4xl font-bold tracking-tighter mb-4">How XENIA Works</h2>
	      <p className="text-gray-600 max-w-2xl mx-auto">
	        A simple four-step process to transform your learning experience.
	      </p>
	    </div>
	
	    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
	      <div className="text-center">
	        <div className="w-16 h-16 bg-black text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-6">1</div>
	        <h3 className="text-xl font-bold mb-2">Upload Your Syllabus</h3>
	        <p className="text-gray-600">
	          Start by uploading your course materials and setting your exam dates.
	        </p>
	      </div>
	
	      <div className="text-center">
	        <div className="w-16 h-16 bg-black text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-6">2</div>
	        <h3 className="text-xl font-bold mb-2">Complete Assessments</h3>
	        <p className="text-gray-600">
	          Take initial assessments to identify your strengths and weaknesses.
	        </p>
	      </div>
	
	      <div className="text-center">
	        <div className="w-16 h-16 bg-black text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-6">3</div>
	        <h3 className="text-xl font-bold mb-2">Follow Your Plan</h3>
	        <p className="text-gray-600">
	          Get a personalized study schedule that adapts to your progress.
	        </p>
	      </div>
	
	      <div className="text-center">
	        <div className="w-16 h-16 bg-black text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-6">4</div>
	        <h3 className="text-xl font-bold mb-2">Track & Improve</h3>
	        <p className="text-gray-600">
	          Monitor your progress and adjust your approach based on insights.
	        </p>
	      </div>
	    </div>
	
	    <div className="mt-16 bg-gray-50 rounded-2xl p-8 flex flex-col md:flex-row items-center gap-8">
	      <div className="md:w-1/2">
	        <h3 className="text-2xl font-bold mb-4">See XENIA in Action</h3>
	        <p className="text-gray-600 mb-6">
	          Watch a quick demo of how XENIA can revolutionize your study routine and help you achieve your academic goals.
	        </p>
	        <button className="bg-black text-white px-6 py-3 font-medium rounded-md hover:bg-gray-800 transition-all flex items-center gap-2">
	          <span className="material-symbols-outlined">play_circle</span>
	          Watch Demo
	        </button>
	      </div>
	      <div className="md:w-1/2 bg-white rounded-xl overflow-hidden border border-gray-100 shadow-lg">
	        <img src="https://images.unsplash.com/photo-1571260899304-425eee4c7efc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80" alt="XENIA Demo" className="w-full h-64 object-cover" keywords="study planner, student dashboard, AI education app" />
	      </div>
	    </div>
	  </section>
	
	  {/* Pricing */}
	  <section id="pricing" className="py-24 px-8 md:px-16 lg:px-24 bg-gray-50">
	    <div className="text-center mb-16">
	      <h2 className="text-4xl font-bold tracking-tighter mb-4">Simple Pricing</h2>
	      <p className="text-gray-600 max-w-2xl mx-auto">
	        Choose the plan that works best for your learning journey.
	      </p>
	    </div>
	
	    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
	      <div className="bg-white rounded-2xl border border-gray-100 p-8 hover:shadow-lg transition-all">
	        <h3 className="text-2xl font-bold mb-2">Free</h3>
	        <p className="text-gray-600 mb-6">Perfect for getting started</p>
	        <div className="text-4xl font-bold mb-6">$0<span className="text-lg font-normal text-gray-600">/month</span></div>
	        <ul className="space-y-4 mb-8">
	          <li className="flex items-center gap-2">
	            <span className="material-symbols-outlined text-green-500">check_circle</span>
	            <span>Basic study planner</span>
	          </li>
	          <li className="flex items-center gap-2">
	            <span className="material-symbols-outlined text-green-500">check_circle</span>
	            <span>Limited AI tutor interactions</span>
	          </li>
	          <li className="flex items-center gap-2">
	            <span className="material-symbols-outlined text-green-500">check_circle</span>
	            <span>Basic progress tracking</span>
	          </li>
	          <li className="flex items-center gap-2">
	            <span className="material-symbols-outlined text-green-500">check_circle</span>
	            <span>1 subject at a time</span>
	          </li>
	        </ul>
	        <a href="/register" className="block w-full border border-gray-200 text-center px-6 py-3 rounded-md font-medium hover:bg-gray-50 transition-all">
	          Get Started
	        </a>
	      </div>
	
	      <div className="bg-black text-white rounded-2xl p-8 hover:shadow-lg transition-all relative overflow-hidden">
	        <div className="absolute top-4 right-4 bg-primary-500 text-white text-xs font-bold px-3 py-1 rounded-full">
	          POPULAR
	        </div>
	        <h3 className="text-2xl font-bold mb-2">Premium</h3>
	        <p className="text-gray-300 mb-6">For serious students</p>
	        <div className="text-4xl font-bold mb-6">$9.99<span className="text-lg font-normal text-gray-300">/month</span></div>
	        <ul className="space-y-4 mb-8">
	          <li className="flex items-center gap-2">
	            <span className="material-symbols-outlined text-primary-500">check_circle</span>
	            <span>Advanced study planner</span>
	          </li>
	          <li className="flex items-center gap-2">
	            <span className="material-symbols-outlined text-primary-500">check_circle</span>
	            <span>Unlimited AI tutor</span>
	          </li>
	          <li className="flex items-center gap-2">
	            <span className="material-symbols-outlined text-primary-500">check_circle</span>
	            <span>Detailed analytics</span>
	          </li>
	          <li className="flex items-center gap-2">
	            <span className="material-symbols-outlined text-primary-500">check_circle</span>
	            <span>Unlimited subjects</span>
	          </li>
	          <li className="flex items-center gap-2">
	            <span className="material-symbols-outlined text-primary-500">check_circle</span>
	            <span>Teacher & parent features</span>
	          </li>
	          <li className="flex items-center gap-2">
	            <span className="material-symbols-outlined text-primary-500">check_circle</span>
	            <span>Priority support</span>
	          </li>
	        </ul>
	        <a href="/register?plan=premium" className="block w-full bg-white text-black text-center px-6 py-3 rounded-md font-medium hover:bg-gray-100 transition-all">
	          Get Premium
	        </a>
	      </div>
	    </div>
	  </section>
	
	  {/* FAQ */}
	  <section id="faq" className="py-24 px-8 md:px-16 lg:px-24">
	    <div className="text-center mb-16">
	      <h2 className="text-4xl font-bold tracking-tighter mb-4">Frequently Asked Questions</h2>
	      <p className="text-gray-600 max-w-2xl mx-auto">
	        Get answers to common questions about XENIA.
	      </p>
	    </div>
	
	    <div className="max-w-3xl mx-auto space-y-4">
	      <details className="bg-white rounded-lg border border-gray-100 p-6 cursor-pointer hover:shadow-md transition-all">
	        <summary className="font-bold text-xl flex justify-between items-center">
	          How does XENIA create personalized study plans?
	          <span className="material-symbols-outlined">add</span>
	        </summary>
	        <div className="mt-4 text-gray-600">
	          XENIA analyzes your syllabus, assessment results, and learning patterns to create a tailored study plan. It identifies your strengths and weaknesses, allocates more time to challenging topics, and adjusts dynamically as you progress.
	        </div>
	      </details>
	
	      <details className="bg-white rounded-lg border border-gray-100 p-6 cursor-pointer hover:shadow-md transition-all">
	        <summary className="font-bold text-xl flex justify-between items-center">
	          Can I use XENIA for any subject?
	          <span className="material-symbols-outlined">add</span>
	        </summary>
	        <div className="mt-4 text-gray-600">
	          Yes! XENIA works for any subject and educational level, from high school to university and professional certifications. The AI adapts to your specific field of study.
	        </div>
	      </details>
	
	      <details className="bg-white rounded-lg border border-gray-100 p-6 cursor-pointer hover:shadow-md transition-all">
	        <summary className="font-bold text-xl flex justify-between items-center">
	          How does the AI tutor work?
	          <span className="material-symbols-outlined">add</span>
	        </summary>
	        <div className="mt-4 text-gray-600">
	          The AI tutor can answer questions, explain concepts, and help you solve problems. You can send text questions or upload images of problems (using OCR technology), and the AI will provide detailed explanations and additional resources.
	        </div>
	      </details>
	
	      <details className="bg-white rounded-lg border border-gray-100 p-6 cursor-pointer hover:shadow-md transition-all">
	        <summary className="font-bold text-xl flex justify-between items-center">
	          Can teachers and parents access my study data?
	          <span className="material-symbols-outlined">add</span>
	        </summary>
	        <div className="mt-4 text-gray-600">
	          Only if you grant them permission. You can invite teachers to tag weak topics and provide guidance, and share progress reports with parents. You control who sees your data.
	        </div>
	      </details>
	
	      <details className="bg-white rounded-lg border border-gray-100 p-6 cursor-pointer hover:shadow-md transition-all">
	        <summary className="font-bold text-xl flex justify-between items-center">
	          Is there a mobile app available?
	          <span className="material-symbols-outlined">add</span>
	        </summary>
	        <div className="mt-4 text-gray-600">
	          Yes, XENIA is available on iOS and Android. The mobile app syncs with the web version, so you can access your study plan and AI tutor on the go.
	        </div>
	      </details>
	    </div>
	  </section>
	
	  {/* CTA */}
	  <section className="py-24 px-8 md:px-16 lg:px-24 bg-black text-white text-center">
	    <h2 className="text-4xl font-bold tracking-tighter mb-6">Ready to Transform Your Learning?</h2>
	    <p className="text-xl mb-8 max-w-2xl mx-auto">
	      Join thousands of students who are studying smarter, not harder, with XENIA.
	    </p>
	    <div className="flex flex-col sm:flex-row gap-4 justify-center">
	      <a href="/register" className="bg-white text-black px-8 py-3 font-medium rounded-md hover:bg-gray-100 transition-all">
	        Get Started Free
	      </a>
	      <a href="#pricing" className="border border-white px-8 py-3 font-medium rounded-md hover:bg-white hover:text-black transition-all">
	        View Pricing
	      </a>
	    </div>
	  </section>
	
	  {/* Footer */}
	  <footer className="bg-black text-white py-16 px-8 md:px-16 lg:px-24">
	    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
	      <div>
	        <div className="flex items-center gap-2 mb-6">
	          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
	            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
	            <path d="M2 17L12 22L22 17" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
	            <path d="M2 12L12 17L22 12" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
	          </svg>
	          <h1 className="font-bold text-xl tracking-tighter">XENIA</h1>
	        </div>
	        <p className="text-gray-400 mb-4">
	          Your AI-powered personal study planner and tutor.
	        </p>
	        <div className="flex gap-4">
	          <a href="#" className="text-gray-400 hover:text-white transition-all">
	            <i className="fa-brands fa-twitter text-xl"></i>
	          </a>
	          <a href="#" className="text-gray-400 hover:text-white transition-all">
	            <i className="fa-brands fa-facebook text-xl"></i>
	          </a>
	          <a href="#" className="text-gray-400 hover:text-white transition-all">
	            <i className="fa-brands fa-instagram text-xl"></i>
	          </a>
	          <a href="#" className="text-gray-400 hover:text-white transition-all">
	            <i className="fa-brands fa-linkedin text-xl"></i>
	          </a>
	        </div>
	      </div>
	
	      <div>
	        <h3 className="font-bold mb-4">Product</h3>
	        <ul className="space-y-2">
	          <li></li></ul></div></div></footer></div> 
        </div>
  )
}

